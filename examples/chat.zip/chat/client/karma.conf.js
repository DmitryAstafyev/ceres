// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html
const webpackConfig = require('./webpack.config');
delete webpackConfig.entry;
webpackConfig.mode = "development";
webpackConfig.devtool = 'inline-source-map';

module.exports = function(config) {
  config.set({
      frameworks: ["jasmine", "karma-typescript"],
      files: [
        "spec/client.spec.ts",
        { pattern: './build/*.css', watched: true, served: true, included: true },
      ],
      preprocessors: {
          "**/*.ts": ['webpack', 'sourcemap']
      },
      webpack: webpackConfig,
      reporters: ["progress", "kjhtml"],
      browsers: ["Chrome"],
      karmaTypescriptConfig: {
        "compilerOptions": {
            "target": "es6",
            "lib": ["es5", "es6", "dom"],
          }
      },
      client: {
        clearContext: false,
        jasmine: {
          random: false,
          oneFailurePerSpec: false,
          failFast: false,
          timeoutInterval: 900000
        }
      }
  });
};